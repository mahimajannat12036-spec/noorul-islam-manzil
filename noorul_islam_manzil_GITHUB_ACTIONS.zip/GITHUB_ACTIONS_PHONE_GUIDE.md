# ফোন দিয়ে APK বানানোর সহজ পদ্ধতি

1. GitHub-এ নতুন repository তৈরি করুন।
2. এই ZIP-এর সব ফাইল repository-তে upload করুন (hidden `.github` folder-সহ)।
3. Commit changes করুন।
4. GitHub-এর **Actions** tab খুলুন।
5. **Build Android APK** workflow নির্বাচন করুন।
6. **Run workflow** চাপুন।
7. Build শেষ হলে workflow run-এর **Artifacts** অংশ থেকে `noorul-islam-manzil-apk` ZIP download করুন।
8. ZIP খুলে `app-release.apk` ফোনে install করুন।

প্রথমবার GitHub Actions build-এ কয়েক মিনিট লাগতে পারে। Play Store প্রয়োজন নেই।
