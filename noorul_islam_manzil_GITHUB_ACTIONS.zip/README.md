# নূরুল ইসলাম মঞ্জিল — Premium Property Manager v1.0

Flutter Android/iOS project for rental, tenant, expense, payment and professional memo management.

## Included
- Tenant add/edit/archive/permanent delete
- Rent payment ledger and payment history
- House expense tracking with categories
- Dashboard with rent, collection, due, expense and net figures
- 3 memo templates
- Professional PDF memo generation with Bengali font asset
- Finger-drawn digital signature capture and persistence
- Memo preview/print/share via the Android/iOS system share/print sheet
- Property identity preconfigured:
  - বাড়ির নাম: নূরুল ইসলাম মঞ্জিল
  - ঠিকানা: এলাহি বি ২৪/১, খুলিয়াপাড়া, আখালিয়া, সিলেট
  - বাসার দায়িত্বে: হোসাইন আহমদ
  - যোগাযোগ: 01729992814

## Run
1. Install Flutter SDK (stable channel).
2. `flutter pub get`
3. `flutter run`
4. For Android release: `flutter build apk --release` or `flutter build appbundle --release`.

## WhatsApp
The memo PDF is shared through the native Android/iOS share sheet, where WhatsApp can be selected. Directly attaching a generated PDF to a WhatsApp chat cannot be guaranteed by a normal `wa.me` URL; the system share sheet is the reliable user-controlled route.

## Important production steps before store release
- Configure Android/iOS application ID and signing keys.
- Add app icon/splash assets.
- Add encrypted cloud backup if multi-device sync is required.
- Test Bengali rendering on target Android devices.
- Add PIN/biometric lock and backup/restore UX if required.
