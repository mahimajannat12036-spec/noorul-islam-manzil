import 'dart:convert';
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:intl/intl.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart' as pdf;
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';

const navy = Color(0xFF082B4C);
const blue = Color(0xFF0E5A8A);
const gold = Color(0xFFD9A441);
const bg = Color(0xFFF4F7FA);
const green = Color(0xFF138A57);

const propertyName = 'নূরুল ইসলাম মঞ্জিল';
const propertyAddress = 'এলাহি বি ২৪/১, খুলিয়াপাড়া, আখালিয়া, সিলেট';
const managerName = 'হোসাইন আহমদ';
const managerPhone = '01729992814';

void main() => runApp(const NoorulIslamManzilApp());

class NoorulIslamManzilApp extends StatelessWidget {
  const NoorulIslamManzilApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        navigatorKey: navigatorKey,
        debugShowCheckedModeBanner: false,
        title: propertyName,
        theme: ThemeData(
          useMaterial3: true,
          scaffoldBackgroundColor: bg,
          fontFamily: 'LohitBengali',
          colorScheme: ColorScheme.fromSeed(seedColor: blue),
          appBarTheme: const AppBarTheme(backgroundColor: navy, foregroundColor: Colors.white),
          inputDecorationTheme: InputDecorationTheme(
            filled: true,
            fillColor: Colors.white,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide.none),
          ),
        ),
        home: const AppShell(),
      );
}

class Tenant {
  String id, name, phone, room, moveIn, note;
  double rent, deposit, due;
  bool archived;
  Tenant({required this.id, required this.name, required this.phone, required this.room, required this.rent, this.deposit = 0, this.due = 0, this.moveIn = '', this.note = '', this.archived = false});
  Map<String, dynamic> toJson() => {'id': id, 'name': name, 'phone': phone, 'room': room, 'rent': rent, 'deposit': deposit, 'due': due, 'moveIn': moveIn, 'note': note, 'archived': archived};
  factory Tenant.fromJson(Map<String, dynamic> j) => Tenant(id: j['id'] ?? DateTime.now().microsecondsSinceEpoch.toString(), name: j['name'] ?? '', phone: j['phone'] ?? '', room: j['room'] ?? '', rent: (j['rent'] as num?)?.toDouble() ?? 0, deposit: (j['deposit'] as num?)?.toDouble() ?? 0, due: (j['due'] as num?)?.toDouble() ?? 0, moveIn: j['moveIn'] ?? '', note: j['note'] ?? '', archived: j['archived'] ?? false);
}

class Expense {
  String id, title, category, date, note;
  double amount;
  Expense({required this.id, required this.title, required this.category, required this.date, required this.amount, this.note = ''});
  Map<String, dynamic> toJson() => {'id': id, 'title': title, 'category': category, 'date': date, 'amount': amount, 'note': note};
  factory Expense.fromJson(Map<String, dynamic> j) => Expense(id: j['id'] ?? DateTime.now().microsecondsSinceEpoch.toString(), title: j['title'] ?? '', category: j['category'] ?? 'অন্যান্য', date: j['date'] ?? '', amount: (j['amount'] as num?)?.toDouble() ?? 0, note: j['note'] ?? '');
}

class Payment {
  String id, tenantId, date, month, method, memoNo;
  double amount, previousDue, extra;
  Payment({required this.id, required this.tenantId, required this.date, required this.month, required this.method, required this.amount, this.previousDue = 0, this.extra = 0, required this.memoNo});
  Map<String, dynamic> toJson() => {'id': id, 'tenantId': tenantId, 'date': date, 'month': month, 'method': method, 'amount': amount, 'previousDue': previousDue, 'extra': extra, 'memoNo': memoNo};
  factory Payment.fromJson(Map<String, dynamic> j) => Payment(id: j['id'], tenantId: j['tenantId'], date: j['date'], month: j['month'], method: j['method'], amount: (j['amount'] as num).toDouble(), previousDue: (j['previousDue'] as num?)?.toDouble() ?? 0, extra: (j['extra'] as num?)?.toDouble() ?? 0, memoNo: j['memoNo']);
}

class AppShell extends StatefulWidget {
  const AppShell({super.key});
  @override State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int index = 0;
  List<Tenant> tenants = [];
  List<Expense> expenses = [];
  List<Payment> payments = [];
  Uint8List? signature;
  int template = 0;

  @override void initState() { super.initState(); _load(); }
  Future<void> _load() async {
    final p = await SharedPreferences.getInstance();
    setState(() {
      tenants = (jsonDecode(p.getString('tenants') ?? '[]') as List).map((e) => Tenant.fromJson(e)).toList();
      expenses = (jsonDecode(p.getString('expenses') ?? '[]') as List).map((e) => Expense.fromJson(e)).toList();
      payments = (jsonDecode(p.getString('payments') ?? '[]') as List).map((e) => Payment.fromJson(e)).toList();
      final s = p.getString('signature');
      signature = s == null ? null : base64Decode(s);
      template = p.getInt('template') ?? 0;
    });
  }
  Future<void> _save() async {
    final p = await SharedPreferences.getInstance();
    await p.setString('tenants', jsonEncode(tenants.map((e) => e.toJson()).toList()));
    await p.setString('expenses', jsonEncode(expenses.map((e) => e.toJson()).toList()));
    await p.setString('payments', jsonEncode(payments.map((e) => e.toJson()).toList()));
    if (signature != null) await p.setString('signature', base64Encode(signature!)); else await p.remove('signature');
    await p.setInt('template', template);
  }
  void addTenant(Tenant t) { setState(() => tenants.add(t)); _save(); }
  void updateTenant(Tenant t) { setState(() { final i = tenants.indexWhere((x) => x.id == t.id); if (i >= 0) tenants[i] = t; }); _save(); }
  void archiveTenant(Tenant t) { t.archived = true; updateTenant(t); }
  void deleteTenant(Tenant t) { setState(() => tenants.removeWhere((x) => x.id == t.id)); _save(); }
  void addExpense(Expense e) { setState(() => expenses.add(e)); _save(); }
  void addPayment(Payment p) { setState(() { payments.add(p); final i = tenants.indexWhere((t) => t.id == p.tenantId); if (i >= 0) tenants[i].due = (tenants[i].due + tenants[i].rent + p.extra + p.previousDue - p.amount).clamp(0, double.infinity); }); _save(); }

  @override Widget build(BuildContext context) {
    final active = tenants.where((t) => !t.archived).toList();
    final pages = [
      DashboardPage(tenants: active, expenses: expenses, payments: payments, onAddTenant: () => _tenantDialog()),
      TenantsPage(tenants: tenants, onAdd: () => _tenantDialog(), onEdit: (t) => _tenantDialog(existing: t), onArchive: archiveTenant, onDelete: deleteTenant),
      ExpensesPage(expenses: expenses, onAdd: () => _expenseDialog()),
      MemoPage(tenants: active, signature: signature, template: template, payments: payments, onSignature: _captureSignature, onTemplate: (v) { setState(() => template = v); _save(); }, onPay: _paymentDialog),
      SettingsPage(onSignature: _captureSignature, hasSignature: signature != null),
    ];
    return Scaffold(
      body: SafeArea(child: IndexedStack(index: index, children: pages)),
      bottomNavigationBar: NavigationBar(selectedIndex: index, onDestinationSelected: (v) => setState(() => index = v), destinations: const [
        NavigationDestination(icon: Icon(Icons.dashboard_outlined), selectedIcon: Icon(Icons.dashboard), label: 'ড্যাশবোর্ড'),
        NavigationDestination(icon: Icon(Icons.people_outline), selectedIcon: Icon(Icons.people), label: 'ভাড়াটিয়া'),
        NavigationDestination(icon: Icon(Icons.receipt_long_outlined), selectedIcon: Icon(Icons.receipt_long), label: 'খরচ'),
        NavigationDestination(icon: Icon(Icons.description_outlined), selectedIcon: Icon(Icons.description), label: 'মেমো'),
        NavigationDestination(icon: Icon(Icons.settings_outlined), selectedIcon: Icon(Icons.settings), label: 'সেটিংস'),
      ]),
    );
  }

  Future<void> _captureSignature() async {
    final s = await Navigator.push<Uint8List?>(context, MaterialPageRoute(builder: (_) => const SignaturePage()));
    if (s != null) { setState(() => signature = s); _save(); }
  }

  Future<void> _tenantDialog({Tenant? existing}) async {
    final name = TextEditingController(text: existing?.name), phone = TextEditingController(text: existing?.phone), room = TextEditingController(text: existing?.room), rent = TextEditingController(text: existing?.rent.toStringAsFixed(0)), deposit = TextEditingController(text: existing?.deposit.toStringAsFixed(0)), note = TextEditingController(text: existing?.note);
    await showDialog(context: context, builder: (_) => AlertDialog(
      title: Text(existing == null ? 'নতুন ভাড়াটিয়া যোগ করুন' : 'ভাড়াটিয়ার তথ্য সম্পাদনা'),
      content: SingleChildScrollView(child: Column(children: [
        TextField(controller: name, decoration: const InputDecoration(labelText: 'ভাড়াটিয়ার নাম *')),
        const SizedBox(height: 10), TextField(controller: phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'মোবাইল / WhatsApp')),
        const SizedBox(height: 10), TextField(controller: room, decoration: const InputDecoration(labelText: 'ফ্ল্যাট / রুম')),
        const SizedBox(height: 10), TextField(controller: rent, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'মাসিক ভাড়া (৳)')),
        const SizedBox(height: 10), TextField(controller: deposit, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'জামানত / অগ্রিম (৳)')),
        const SizedBox(height: 10), TextField(controller: note, maxLines: 2, decoration: const InputDecoration(labelText: 'নোট')),
      ])),
      actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('বাতিল')), FilledButton(onPressed: () { if (name.text.trim().isEmpty) return; final t = Tenant(id: existing?.id ?? DateTime.now().microsecondsSinceEpoch.toString(), name: name.text.trim(), phone: phone.text.trim(), room: room.text.trim(), rent: double.tryParse(rent.text) ?? 0, deposit: double.tryParse(deposit.text) ?? 0, due: existing?.due ?? 0, note: note.text.trim(), archived: existing?.archived ?? false); existing == null ? addTenant(t) : updateTenant(t); Navigator.pop(context); }, child: const Text('সংরক্ষণ'))],
    ));
  }

  Future<void> _expenseDialog() async {
    final title = TextEditingController(), amount = TextEditingController(), note = TextEditingController(); String category = 'রক্ষণাবেক্ষণ';
    await showDialog(context: context, builder: (_) => StatefulBuilder(builder: (context, setD) => AlertDialog(
      title: const Text('নতুন খরচ যোগ করুন'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [TextField(controller: title, decoration: const InputDecoration(labelText: 'খরচের বিবরণ *')), const SizedBox(height: 10), DropdownButtonFormField<String>(value: category, items: ['বিদ্যুৎ','পানি','গ্যাস','ইন্টারনেট','রক্ষণাবেক্ষণ','পরিষ্কার-পরিচ্ছন্নতা','নিরাপত্তা','অন্যান্য'].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(), onChanged: (v) => setD(() => category = v!), decoration: const InputDecoration(labelText: 'ক্যাটাগরি')), const SizedBox(height: 10), TextField(controller: amount, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'পরিমাণ (৳)')), const SizedBox(height: 10), TextField(controller: note, decoration: const InputDecoration(labelText: 'নোট'))]),
      actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('বাতিল')), FilledButton(onPressed: () { if (title.text.trim().isEmpty) return; addExpense(Expense(id: DateTime.now().microsecondsSinceEpoch.toString(), title: title.text.trim(), category: category, date: DateFormat('dd MMM yyyy').format(DateTime.now()), amount: double.tryParse(amount.text) ?? 0, note: note.text.trim())); Navigator.pop(context); }, child: const Text('সংরক্ষণ'))],
    )));
  }

  Future<void> _paymentDialog(Tenant tenant) async {
    final amount = TextEditingController(text: tenant.rent.toStringAsFixed(0)), extra = TextEditingController(); String method = 'নগদ';
    await showDialog(context: context, builder: (_) => StatefulBuilder(builder: (context, setD) => AlertDialog(
      title: Text('${tenant.name}-এর ভাড়া গ্রহণ'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [Text('বর্তমান বকেয়া: ৳${tenant.due.toStringAsFixed(2)}'), const SizedBox(height: 10), TextField(controller: amount, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'পরিশোধিত মোট টাকা (৳)')), const SizedBox(height: 10), TextField(controller: extra, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'অতিরিক্ত চার্জ (৳)')), const SizedBox(height: 10), DropdownButtonFormField<String>(value: method, items: ['নগদ','বিকাশ','নগদ (Nagad)','ব্যাংক','অন্যান্য'].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(), onChanged: (v) => setD(() => method = v!), decoration: const InputDecoration(labelText: 'পেমেন্ট পদ্ধতি'))]),
      actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('বাতিল')), FilledButton(onPressed: () { final paid = double.tryParse(amount.text) ?? 0; if (paid <= 0) return; final now = DateTime.now(); final memoNo = 'NIM-${DateFormat('yyyyMMdd-HHmmss').format(now)}'; addPayment(Payment(id: now.microsecondsSinceEpoch.toString(), tenantId: tenant.id, date: DateFormat('dd MMM yyyy').format(now), month: DateFormat('MMMM yyyy').format(now), method: method, amount: paid, previousDue: tenant.due, extra: double.tryParse(extra.text) ?? 0, memoNo: memoNo)); Navigator.pop(context); _openMemo(tenant, paid, memoNo, method); }, child: const Text('ভাড়া গ্রহণ করুন'))],
    )));
  }

  void _openMemo(Tenant tenant, double paid, String memoNo, String method) => Navigator.push(context, MaterialPageRoute(builder: (_) => MemoPreviewPage(tenant: tenant, paid: paid, memoNo: memoNo, method: method, signature: signature, template: template)));
}

class Header extends StatelessWidget { final String title, subtitle; const Header({super.key, required this.title, required this.subtitle}); @override Widget build(BuildContext context) => Container(width: double.infinity, padding: const EdgeInsets.fromLTRB(20, 22, 20, 22), decoration: const BoxDecoration(color: navy, borderRadius: BorderRadius.vertical(bottom: Radius.circular(28))), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(propertyName, style: const TextStyle(color: gold, fontSize: 17, fontWeight: FontWeight.w700)), const SizedBox(height: 4), Text(title, style: const TextStyle(color: Colors.white, fontSize: 26, fontWeight: FontWeight.w800)), const SizedBox(height: 3), Text(subtitle, style: const TextStyle(color: Colors.white70)), const SizedBox(height: 12), Text('বাসার দায়িত্বে: $managerName  •  $managerPhone', style: const TextStyle(color: Colors.white, fontSize: 12))])); }

class DashboardPage extends StatelessWidget { final List<Tenant> tenants; final List<Expense> expenses; final List<Payment> payments; final VoidCallback onAddTenant; const DashboardPage({super.key, required this.tenants, required this.expenses, required this.payments, required this.onAddTenant}); @override Widget build(BuildContext context) { final expected = tenants.fold<double>(0, (s,t) => s+t.rent); final collected = payments.where((p) => DateTime.tryParse(p.date) == null || true).fold<double>(0,(s,p)=>s+p.amount); final due = tenants.fold<double>(0,(s,t)=>s+t.due); final cost = expenses.fold<double>(0,(s,e)=>s+e.amount); return ListView(children: [Header(title:'স্মার্ট প্রপার্টি ম্যানেজমেন্ট', subtitle:'ভাড়া, খরচ ও ডিজিটাল মেমো—সব এক জায়গায়'), Padding(padding: const EdgeInsets.all(16), child: Column(children: [Row(children: [StatCard(label:'সক্রিয় ভাড়াটিয়া', value:'${tenants.length}', icon:Icons.people), const SizedBox(width:10), StatCard(label:'মাসিক ভাড়া', value:'৳${expected.toStringAsFixed(0)}', icon:Icons.payments)]), const SizedBox(height:10), Row(children: [StatCard(label:'মোট আদায়', value:'৳${collected.toStringAsFixed(0)}', icon:Icons.check_circle), const SizedBox(width:10), StatCard(label:'বকেয়া', value:'৳${due.toStringAsFixed(0)}', icon:Icons.warning_amber)]), const SizedBox(height:10), Row(children: [StatCard(label:'মোট খরচ', value:'৳${cost.toStringAsFixed(0)}', icon:Icons.receipt_long), const SizedBox(width:10), StatCard(label:'নিট অবস্থান', value:'৳${(collected-cost).toStringAsFixed(0)}', icon:Icons.account_balance_wallet)]), const SizedBox(height:18), Container(width: double.infinity, padding: const EdgeInsets.all(18), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(22)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('দ্রুত কাজ', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: navy)), const SizedBox(height: 12), SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: onAddTenant, icon: const Icon(Icons.person_add), label: const Text('নতুন ভাড়াটিয়া যোগ করুন')))]))]))]); } }
class StatCard extends StatelessWidget { final String label,value; final IconData icon; const StatCard({super.key,required this.label,required this.value,required this.icon}); @override Widget build(BuildContext c)=>Expanded(child:Container(padding:const EdgeInsets.all(16),decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(20)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Icon(icon,color:blue),const SizedBox(height:8),Text(label,style:const TextStyle(color:Colors.black54)),const SizedBox(height:2),Text(value,style:const TextStyle(fontSize:19,fontWeight:FontWeight.w800,color:navy))]))); }

class TenantsPage extends StatelessWidget { final List<Tenant> tenants; final VoidCallback onAdd; final void Function(Tenant) onEdit,onArchive,onDelete; const TenantsPage({super.key,required this.tenants,required this.onAdd,required this.onEdit,required this.onArchive,required this.onDelete}); @override Widget build(BuildContext c)=>Column(children:[Header(title:'ভাড়াটিয়া ব্যবস্থাপনা',subtitle:'যোগ • সম্পাদনা • আর্কাইভ • স্থায়ীভাবে মুছে ফেলা'),Expanded(child:ListView.builder(padding:const EdgeInsets.all(16),itemCount:tenants.length,itemBuilder:(c,i){final t=tenants[i];return Card(margin:const EdgeInsets.only(bottom:10),shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(18)),child:ListTile(leading:CircleAvatar(backgroundColor:t.archived?Colors.grey:blue,child:Text(t.name.isNotEmpty?t.name[0]:'?',style:const TextStyle(color:Colors.white))),title:Text(t.name,style:const TextStyle(fontWeight:FontWeight.bold)),subtitle:Text('${t.room}  •  ${t.phone}\nভাড়া: ৳${t.rent.toStringAsFixed(0)}  •  বকেয়া: ৳${t.due.toStringAsFixed(0)}'),isThreeLine:true,trailing:PopupMenuButton<String>(onSelected:(v){if(v=='edit')onEdit(t); if(v=='archive')onArchive(t); if(v=='delete')_confirmDelete(c,t);},itemBuilder:(_)=>[const PopupMenuItem(value:'edit',child:Text('সম্পাদনা')),if(!t.archived)const PopupMenuItem(value:'archive',child:Text('আর্কাইভ')),const PopupMenuItem(value:'delete',child:Text('স্থায়ীভাবে মুছে ফেলুন'))]),onTap:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>TenantDetailPage(tenant:t)))));}),),Padding(padding:const EdgeInsets.all(16),child:SizedBox(width:double.infinity,child:FilledButton.icon(onPressed:onAdd,icon:const Icon(Icons.add),label:const Text('ভাড়াটিয়া যোগ করুন'))))]); void _confirmDelete(BuildContext c,Tenant t)=>showDialog(context:c,builder:(_)=>AlertDialog(title:const Text('স্থায়ীভাবে মুছে ফেলবেন?'),content:const Text('এটি শুধু ভাড়াটিয়ার রেকর্ড মুছবে। আগে Archive ব্যবহার করা নিরাপদ।'),actions:[TextButton(onPressed:()=>Navigator.pop(c),child:const Text('বাতিল')),FilledButton(onPressed:(){onDelete(t);Navigator.pop(c);},child:const Text('মুছে ফেলুন'))])); }
class TenantDetailPage extends StatelessWidget { final Tenant tenant; const TenantDetailPage({super.key,required this.tenant}); @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('ভাড়াটিয়ার তথ্য')),body:ListView(padding:const EdgeInsets.all(20),children:[Text(tenant.name,style:const TextStyle(fontSize:28,fontWeight:FontWeight.w800,color:navy)),const SizedBox(height:15),InfoTile(label:'ফ্ল্যাট / রুম',value:tenant.room),InfoTile(label:'মোবাইল / WhatsApp',value:tenant.phone),InfoTile(label:'মাসিক ভাড়া',value:'৳${tenant.rent.toStringAsFixed(2)}'),InfoTile(label:'জামানত / অগ্রিম',value:'৳${tenant.deposit.toStringAsFixed(2)}'),InfoTile(label:'বর্তমান বকেয়া',value:'৳${tenant.due.toStringAsFixed(2)}'),InfoTile(label:'অবস্থা',value:tenant.archived?'আর্কাইভ করা':'সক্রিয়'),if(tenant.note.isNotEmpty)InfoTile(label:'নোট',value:tenant.note)])); }
class InfoTile extends StatelessWidget { final String label,value; const InfoTile({super.key,required this.label,required this.value}); @override Widget build(BuildContext c)=>Container(margin:const EdgeInsets.only(bottom:10),padding:const EdgeInsets.all(16),decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(16)),child:Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[Text(label,style:const TextStyle(color:Colors.black54)),Flexible(child:Text(value,textAlign:TextAlign.right,style:const TextStyle(fontWeight:FontWeight.w700)))])); }

class ExpensesPage extends StatelessWidget { final List<Expense> expenses; final VoidCallback onAdd; const ExpensesPage({super.key,required this.expenses,required this.onAdd}); @override Widget build(BuildContext c){final total=expenses.fold<double>(0,(s,e)=>s+e.amount);return Column(children:[Header(title:'বাসার খরচ',subtitle:'প্রতিটি খরচের পরিষ্কার ও পেশাদার হিসাব'),Padding(padding:const EdgeInsets.all(16),child:Container(width:double.infinity,padding:const EdgeInsets.all(18),decoration:BoxDecoration(color:navy,borderRadius:BorderRadius.circular(20)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('মোট খরচ',style:TextStyle(color:Colors.white70)),Text('৳${total.toStringAsFixed(2)}',style:const TextStyle(color:Colors.white,fontSize:28,fontWeight:FontWeight.w800))])),Expanded(child:ListView.builder(itemCount:expenses.length,padding:const EdgeInsets.symmetric(horizontal:16),itemBuilder:(c,i){final e=expenses[i];return Card(child:ListTile(leading:const CircleAvatar(child:Icon(Icons.receipt)),title:Text(e.title,style:const TextStyle(fontWeight:FontWeight.bold)),subtitle:Text('${e.category} • ${e.date}'),trailing:Text('৳${e.amount.toStringAsFixed(2)}',style:const TextStyle(fontWeight:FontWeight.w800)));})),Padding(padding:const EdgeInsets.all(16),child:SizedBox(width:double.infinity,child:FilledButton.icon(onPressed:onAdd,icon:const Icon(Icons.add),label:const Text('নতুন খরচ যোগ করুন'))))]);}}

class MemoPage extends StatefulWidget { final List<Tenant> tenants; final Uint8List? signature; final int template; final List<Payment> payments; final VoidCallback onSignature; final ValueChanged<int> onTemplate; final void Function(Tenant) onPay; const MemoPage({super.key,required this.tenants,required this.signature,required this.template,required this.payments,required this.onSignature,required this.onTemplate,required this.onPay}); @override State<MemoPage> createState()=>_MemoPageState(); }
class _MemoPageState extends State<MemoPage>{Tenant? selected; @override Widget build(BuildContext c)=>ListView(children:[Header(title:'ডিজিটাল মেমো',subtitle:'Premium receipt • একাধিক template • finger signature'),Padding(padding:const EdgeInsets.all(16),child:Column(children:[DropdownButtonFormField<Tenant>(value:selected,items:widget.tenants.map((t)=>DropdownMenuItem(value:t,child:Text('${t.name} • ${t.room}'))).toList(),onChanged:(v)=>setState(()=>selected=v),decoration:const InputDecoration(labelText:'ভাড়াটিয়া নির্বাচন করুন')),const SizedBox(height:12),DropdownButtonFormField<int>(value:widget.template,items:const[DropdownMenuItem(value:0,child:Text('Classic Premium')),DropdownMenuItem(value:1,child:Text('Royal Dark')),DropdownMenuItem(value:2,child:Text('Modern Minimal'))],onChanged:(v){if(v!=null)widget.onTemplate(v);},decoration:const InputDecoration(labelText:'Memo Template')),const SizedBox(height:12),Container(padding:const EdgeInsets.all(18),decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(20)),child:Row(children:[Container(width:70,height:55,decoration:BoxDecoration(borderRadius:BorderRadius.circular(12),color:bg),child:widget.signature==null?const Icon(Icons.draw,color:blue):Image.memory(widget.signature!,fit:BoxFit.contain)),const SizedBox(width:12),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('Digital Signature',style:TextStyle(fontWeight:FontWeight.w800)),Text(widget.signature==null?'এখনও স্বাক্ষর সংরক্ষণ করা হয়নি':'স্বাক্ষর সংরক্ষিত আছে')]),),OutlinedButton(onPressed:widget.onSignature,child:Text(widget.signature==null?'স্বাক্ষর দিন':'পরিবর্তন'))])),const SizedBox(height:16),if(selected!=null)SizedBox(width:double.infinity,child:FilledButton.icon(onPressed:()=>widget.onPay(selected!),icon:const Icon(Icons.payments),label:const Text('ভাড়া গ্রহণ ও মেমো তৈরি করুন')),if(selected!=null)const SizedBox(height:10),if(selected!=null)SizedBox(width:double.infinity,child:OutlinedButton.icon(onPressed:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>PaymentHistoryPage(tenant:selected!,payments:widget.payments))),icon:const Icon(Icons.history),label:const Text('এই ভাড়াটিয়ার পেমেন্ট ইতিহাস')))]))]); }
}

class MemoPreviewPage extends StatelessWidget { final Tenant tenant; final double paid; final String memoNo, method; final Uint8List? signature; final int template; const MemoPreviewPage({super.key,required this.tenant,required this.paid,required this.memoNo,required this.method,required this.signature,required this.template});
  Future<Uint8List> _pdf() async { final doc=pw.Document(); final fontData=await DefaultAssetBundle.of(navigatorKey.currentContext!).load('assets/fonts/Lohit-Bengali.ttf'); final font=pw.Font.ttf(fontData); final bold=pw.Font.ttf(fontData); final due=(tenant.due+tenant.rent-paid).clamp(0,double.infinity); final c=template==1?pdf.PdfColors.blueGrey900:template==2?pdf.PdfColors.white:pdf.PdfColors.blue900; final textColor=template==2?pdf.PdfColors.grey900:pdf.PdfColors.white; final bgc=template==2?pdf.PdfColors.white:pdf.PdfColors.blue50; pw.ImageProvider? sig; if(signature!=null)sig=pw.MemoryImage(signature!); doc.addPage(pw.Page(pageFormat:pdf.PdfPageFormat.a4,margin:const pw.EdgeInsets.all(28),theme:pw.ThemeData.withFont(base:font,bold:bold),build:(ctx)=>pw.Container(decoration:pw.BoxDecoration(border:pw.Border.all(color:pdf.PdfColors.blue100,width:1)),padding:const pw.EdgeInsets.all(20),child:pw.Column(crossAxisAlignment:pw.CrossAxisAlignment.start,children:[pw.Container(color:c,padding:const pw.EdgeInsets.all(18),child:pw.Row(mainAxisAlignment:pw.MainAxisAlignment.spaceBetween,children:[pw.Column(crossAxisAlignment:pw.CrossAxisAlignment.start,children:[pw.Text(propertyName,style:pw.TextStyle(color:textColor,fontSize:20,fontWeight:pw.FontWeight.bold)),pw.SizedBox(height:5),pw.Text('মাসিক ভাড়ার রসিদ',style:pw.TextStyle(color:textColor,fontSize:14)),pw.SizedBox(height:5),pw.Text(propertyAddress,style:pw.TextStyle(color:textColor,fontSize:9))]),pw.Text('RENT RECEIPT',style:pw.TextStyle(color:textColor,fontSize:16,fontWeight:pw.FontWeight.bold))])),pw.SizedBox(height:18),pw.Row(children:[pw.Expanded(child:_pdfInfo('ভাড়াটিয়া',tenant.name,font)),pw.SizedBox(width:10),pw.Expanded(child:_pdfInfo('ফ্ল্যাট / রুম',tenant.room,font))]),pw.SizedBox(height:10),pw.Row(children:[pw.Expanded(child:_pdfInfo('মেমো নং',memoNo,font)),pw.SizedBox(width:10),pw.Expanded(child:_pdfInfo('তারিখ',DateFormat('dd MMM yyyy').format(DateTime.now()),font))]),pw.SizedBox(height:18),pw.Table(border:pw.TableBorder.all(color:pdf.PdfColors.blue100),columnWidths:{0:const pw.FlexColumnWidth(3),1:const pw.FlexColumnWidth(1.2)},children:[pw.TableRow(decoration:pw.BoxDecoration(color:bgc),children:[pw.Padding(padding:const pw.EdgeInsets.all(9),child:pw.Text('বিবরণ',style:pw.TextStyle(fontWeight:pw.FontWeight.bold))),pw.Padding(padding:const pw.EdgeInsets.all(9),child:pw.Text('টাকা',style:pw.TextStyle(fontWeight:pw.FontWeight.bold)))]),_row('মাসিক ভাড়া',tenant.rent,font),_row('পূর্বের বকেয়া',tenant.due,font),_row('পরিশোধিত',-paid,font),_row('বর্তমান বকেয়া',due,font)]),pw.SizedBox(height:16),pw.Container(color:bgc,padding:const pw.EdgeInsets.all(14),child:pw.Row(mainAxisAlignment:pw.MainAxisAlignment.spaceBetween,children:[pw.Text('পরিশোধিত টাকা',style:pw.TextStyle(fontSize:14,fontWeight:pw.FontWeight.bold)),pw.Text('৳ ${paid.toStringAsFixed(2)}',style:pw.TextStyle(fontSize:18,fontWeight:pw.FontWeight.bold))])),pw.SizedBox(height:10),pw.Text('পেমেন্ট পদ্ধতি: $method',style:const pw.TextStyle(fontSize:10)),pw.SizedBox(height:30),pw.Row(mainAxisAlignment:pw.MainAxisAlignment.spaceBetween,crossAxisAlignment:pw.CrossAxisAlignment.end,children:[pw.Column(children:[if(sig!=null)pw.Image(sig!,width:110,height:45),pw.Container(width:120,height:1,color:pdf.PdfColors.grey400),pw.SizedBox(height:4),pw.Text(managerName),pw.Text('বাসার দায়িত্বে',style:const pw.TextStyle(fontSize:9))]),pw.Column(crossAxisAlignment:pw.CrossAxisAlignment.end,children:[pw.Text('যোগাযোগ: $managerPhone',style:const pw.TextStyle(fontSize:9)),pw.SizedBox(height:8),pw.Text('ধন্যবাদ',style:pw.TextStyle(fontSize:14,fontWeight:pw.FontWeight.bold))])]),pw.Spacer(),pw.Text('এই রসিদটি নূরুল ইসলাম মঞ্জিলের ডিজিটাল হিসাবের অংশ।',style:const pw.TextStyle(fontSize:8,color:pdf.PdfColors.grey600))]))); return doc.save(); }
  pw.Widget _pdfInfo(String a,String b,pw.Font f)=>pw.Container(padding:const pw.EdgeInsets.all(10),decoration:pw.BoxDecoration(border:pw.Border.all(color:pdf.PdfColors.blue100)),child:pw.Column(crossAxisAlignment:pw.CrossAxisAlignment.start,children:[pw.Text(a,style:pw.TextStyle(fontSize:8,color:pdf.PdfColors.grey600)),pw.SizedBox(height:3),pw.Text(b,style:pw.TextStyle(fontSize:11,fontWeight:pw.FontWeight.bold))]));
  pw.TableRow _row(String a,double b,pw.Font f)=>pw.TableRow(children:[pw.Padding(padding:const pw.EdgeInsets.all(8),child:pw.Text(a)),pw.Padding(padding:const pw.EdgeInsets.all(8),child:pw.Text('৳ ${b.toStringAsFixed(2)}'))]);
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('মেমো প্রিভিউ'),actions:[IconButton(onPressed:() async {final bytes=await _pdf(); await Printing.layoutPdf(onLayout:(_)=>bytes);},icon:const Icon(Icons.print))]),body:PdfPreview(build:(format)=>_pdf(),allowSharing:false,allowPrinting:true,canChangePageFormat:false,canChangeOrientation:false));
}

final navigatorKey = GlobalKey<NavigatorState>();

class PaymentHistoryPage extends StatelessWidget { final Tenant tenant; final List<Payment> payments; const PaymentHistoryPage({super.key,required this.tenant,required this.payments}); @override Widget build(BuildContext c){final list=payments.where((p)=>p.tenantId==tenant.id).toList().reversed.toList();return Scaffold(appBar:AppBar(title:const Text('পেমেন্ট ইতিহাস')),body:list.isEmpty?const Center(child:Text('এখনও কোনো পেমেন্ট রেকর্ড নেই')):ListView.builder(padding:const EdgeInsets.all(16),itemCount:list.length,itemBuilder:(c,i){final p=list[i];return Card(child:ListTile(title:Text('৳${p.amount.toStringAsFixed(2)}',style:const TextStyle(fontWeight:FontWeight.bold)),subtitle:Text('${p.month} • ${p.method}\nমেমো: ${p.memoNo}'),isThreeLine:true));}));}}

class SignaturePage extends StatefulWidget { const SignaturePage({super.key}); @override State<SignaturePage> createState()=>_SignaturePageState(); }
class _SignaturePageState extends State<SignaturePage>{final key=GlobalKey();final points=<Offset>[];bool drawing=false;@override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('ডিজিটাল স্বাক্ষর')),body:Column(children:[const Padding(padding:EdgeInsets.all(16),child:Text('সাদা জায়গায় আঙুল দিয়ে আপনার স্বাক্ষর আঁকুন',style:TextStyle(fontSize:18,fontWeight:FontWeight.bold))),Expanded(child:RepaintBoundary(key:key,child:Container(margin:const EdgeInsets.all(16),decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(20),border:Border.all(color:blue,width:1.5)),child:GestureDetector(onPanStart:(d){drawing=true;points.add(d.localPosition);setState((){});},onPanUpdate:(d){points.add(d.localPosition);setState((){});},onPanEnd:(_){points.add(Offset.infinite);},child:CustomPaint(painter:SignaturePainter(points),size:Size.infinite))))),Padding(padding:const EdgeInsets.all(16),child:Row(children:[Expanded(child:OutlinedButton(onPressed:()=>setState(()=>points.clear()),child:const Text('মুছে আবার আঁকুন'))),const SizedBox(width:10),Expanded(child:FilledButton(onPressed:_save,child:const Text('স্বাক্ষর সংরক্ষণ')))]))]));Future<void>_save()async{if(!drawing)return;final boundary=key.currentContext!.findRenderObject() as RenderRepaintBoundary;final image=await boundary.toImage(pixelRatio:3);final data=await image.toByteData(format:ui.ImageByteFormat.png);if(data!=null)Navigator.pop(c,data.buffer.asUint8List());}}
class SignaturePainter extends CustomPainter{final List<Offset> points;SignaturePainter(this.points);@override void paint(Canvas canvas,Size size){final p=Paint()..color=navy..strokeWidth=3.2..strokeCap=StrokeCap.round..style=PaintingStyle.stroke;for(int i=0;i<points.length-1;i++){if(points[i].isFinite&&points[i+1].isFinite)canvas.drawLine(points[i],points[i+1],p);}}@override bool shouldRepaint(covariant SignaturePainter old)=>true;}

class SettingsPage extends StatelessWidget { final VoidCallback onSignature; final bool hasSignature; const SettingsPage({super.key,required this.onSignature,required this.hasSignature}); @override Widget build(BuildContext c)=>ListView(children:[Header(title:'সেটিংস',subtitle:'প্রপার্টি পরিচয়, স্বাক্ষর ও অ্যাপ নিরাপত্তা'),Padding(padding:const EdgeInsets.all(16),child:Column(children:[InfoTile(label:'বাড়ির নাম',value:propertyName),InfoTile(label:'ঠিকানা',value:propertyAddress),InfoTile(label:'বাসার দায়িত্বে',value:managerName),InfoTile(label:'যোগাযোগ',value:managerPhone),const SizedBox(height:8),Card(child:ListTile(leading:const Icon(Icons.draw,color:blue),title:const Text('Digital Signature'),subtitle:Text(hasSignature?'স্বাক্ষর সংরক্ষিত আছে':'এখনও স্বাক্ষর দেওয়া হয়নি'),trailing:const Icon(Icons.chevron_right),onTap:onSignature)),const Card(child:ListTile(leading:Icon(Icons.security,color:blue),title:Text('PIN / Biometric Lock'),subtitle:Text('পরবর্তী নিরাপত্তা সেটআপে যুক্ত করা যাবে'))),const Card(child:ListTile(leading:Icon(Icons.backup,color:blue),title:Text('Backup & Restore'),subtitle:Text('ডেটা ব্যাকআপ ও পুনরুদ্ধারের ব্যবস্থা')))]))]); }
